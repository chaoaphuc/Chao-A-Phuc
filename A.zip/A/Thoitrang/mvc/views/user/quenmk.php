
    <main class="main_login mt-4 d-flex justify-content-center">
        <div class="form__login">
            <form action="" method="POST" class="grid-column mt-3">
                <div class="input__form__icon card">
                    <i class="far fa-envelope"></i>
                    <input class=" nhap_input_login" type="text" name="email" id="" placeholder="Email của bạn">
                </div>
                <input type="submit" value="Gửi mã" name="gui_ma_mk" class="dang_nhap_dk btn">
            </form>
        </div>
    </main>